
        <?php
            $page = ['name' => 's', 'subpage' => '4-veres-tibor'];
            $metaTitle = '#4 - Veres Tibor';
            include('../index.php');
        ?>
    
    