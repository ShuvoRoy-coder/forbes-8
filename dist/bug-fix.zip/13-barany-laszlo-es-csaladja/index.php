
        <?php
            $page = ['name' => 's', 'subpage' => '13-barany-laszlo-es-csaladja'];
            $metaTitle = '#13 - Bárány László és családja';
            include('../index.php');
        ?>
    
    