
        <?php
            $page = ['name' => 's', 'subpage' => '14-futo-gabor'];
            $metaTitle = '#14 - Futó Gábor';
            include('../index.php');
        ?>
    
    