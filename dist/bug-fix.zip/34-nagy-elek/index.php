
        <?php
            $page = ['name' => 's', 'subpage' => '34-nagy-elek'];
            $metaTitle = '#34 - Nagy Elek';
            include('../index.php');
        ?>
    
    