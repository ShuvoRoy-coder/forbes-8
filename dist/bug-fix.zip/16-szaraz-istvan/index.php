
        <?php
            $page = ['name' => 's', 'subpage' => '16-szaraz-istvan'];
            $metaTitle = '#16 - Száraz István';
            include('../index.php');
        ?>
    
    