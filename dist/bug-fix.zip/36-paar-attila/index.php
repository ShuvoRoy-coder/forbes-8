
        <?php
            $page = ['name' => 's', 'subpage' => '36-paar-attila'];
            $metaTitle = '#36 - Paár Attila';
            include('../index.php');
        ?>
    
    