
        <?php
            $page = ['name' => 's', 'subpage' => '33-levai-csalad'];
            $metaTitle = '#33 - Lévai család';
            include('../index.php');
        ?>
    
    