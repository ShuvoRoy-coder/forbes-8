
        <?php
            $page = ['name' => 's', 'subpage' => '3-felcsuti-zsolt'];
            $metaTitle = '#3 - Felcsuti Zsolt';
            include('../index.php');
        ?>
    
    