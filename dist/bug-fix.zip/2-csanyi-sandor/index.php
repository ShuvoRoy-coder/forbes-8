
        <?php
            $page = ['name' => 's', 'subpage' => '2-csanyi-sandor'];
            $metaTitle = '#2 - Csányi Sándor';
            include('../index.php');
        ?>
    
    