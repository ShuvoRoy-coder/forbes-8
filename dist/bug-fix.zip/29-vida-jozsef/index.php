
        <?php
            $page = ['name' => 's', 'subpage' => '29-vida-jozsef'];
            $metaTitle = '#29 - Vida József';
            include('../index.php');
        ?>
    
    