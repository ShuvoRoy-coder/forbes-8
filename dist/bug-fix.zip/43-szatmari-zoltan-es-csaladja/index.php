
        <?php
            $page = ['name' => 's', 'subpage' => '43-szatmari-zoltan-es-csaladja'];
            $metaTitle = '#43 - Szatmári Zoltán és családja';
            include('../index.php');
        ?>
    
    