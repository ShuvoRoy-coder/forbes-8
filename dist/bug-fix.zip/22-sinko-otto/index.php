
        <?php
            $page = ['name' => 's', 'subpage' => '22-sinko-otto'];
            $metaTitle = '#22 - Sinkó Ottó';
            include('../index.php');
        ?>
    
    