
        <?php
            $page = ['name' => 's', 'subpage' => '1-meszaros-lorinc'];
            $metaTitle = '#1 - Mészáros Lőrinc';
            include('../index.php');
        ?>
    
    