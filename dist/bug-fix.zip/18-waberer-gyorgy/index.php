
        <?php
            $page = ['name' => 's', 'subpage' => '18-waberer-gyorgy'];
            $metaTitle = '#18 - Wáberer György';
            include('../index.php');
        ?>
    
    