
        <?php
            $page = ['name' => 's', 'subpage' => '31-zettwitz-sandor-es-csaladja'];
            $metaTitle = '#31 - Zettwitz Sándor és családja';
            include('../index.php');
        ?>
    
    