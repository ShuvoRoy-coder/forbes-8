
        <?php
            $page = ['name' => 's', 'subpage' => '30-varga-zoltan'];
            $metaTitle = '#30 - Varga Zoltán';
            include('../index.php');
        ?>
    
    