
        <?php
            $page = ['name' => 's', 'subpage' => '10-demjan-sandorne-es-csaladja'];
            $metaTitle = '#10 - Demján Sándorné és családja';
            include('../index.php');
        ?>
    
    