
        <?php
            $page = ['name' => 's', 'subpage' => '49-kis-szolgyemi-ferenc'];
            $metaTitle = '#49 - Kis-Szölgyémi Ferenc';
            include('../index.php');
        ?>
    
    