
        <?php
            $page = ['name' => 's', 'subpage' => '27-santa-janos-es-csaladja'];
            $metaTitle = '#27 - Sánta János és családja';
            include('../index.php');
        ?>
    
    