
        <?php
            $page = ['name' => 's', 'subpage' => '44-adnan-polat-es-csaladja'];
            $metaTitle = '#44 - Adnan Polat és családja';
            include('../index.php');
        ?>
    
    