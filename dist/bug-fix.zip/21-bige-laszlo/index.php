
        <?php
            $page = ['name' => 's', 'subpage' => '21-bige-laszlo'];
            $metaTitle = '#21 - Bige László';
            include('../index.php');
        ?>
    
    