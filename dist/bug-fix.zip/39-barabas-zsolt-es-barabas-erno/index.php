
        <?php
            $page = ['name' => 's', 'subpage' => '39-barabas-zsolt-es-barabas-erno'];
            $metaTitle = '#39 - Barabás Zsolt és Barabás Ernő';
            include('../index.php');
        ?>
    
    