
        <?php
            $page = ['name' => 's', 'subpage' => '42-futo-peter'];
            $metaTitle = '#42 - Futó Péter';
            include('../index.php');
        ?>
    
    