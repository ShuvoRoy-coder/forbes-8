
        <?php
            $page = ['name' => 's', 'subpage' => '7-jellinek-daniel'];
            $metaTitle = '#7 - Jellinek Dániel';
            include('../index.php');
        ?>
    
    