
        <?php
            $page = ['name' => 's', 'subpage' => '37-balasy-gyula'];
            $metaTitle = '#37 - Balásy Gyula';
            include('../index.php');
        ?>
    
    