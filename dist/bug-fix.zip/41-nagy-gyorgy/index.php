
        <?php
            $page = ['name' => 's', 'subpage' => '41-nagy-gyorgy'];
            $metaTitle = '#41 - Nagy György';
            include('../index.php');
        ?>
    
    