
        <?php
            $page = ['name' => 's', 'subpage' => '48-hermann-kamilla'];
            $metaTitle = '#48 - Hermann Kamilla';
            include('../index.php');
        ?>
    
    