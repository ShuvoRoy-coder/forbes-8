
        <?php
            $page = ['name' => 's', 'subpage' => '50-lakatos-benjamin'];
            $metaTitle = '#50 - Lakatos Benjámin';
            include('../index.php');
        ?>
    
    