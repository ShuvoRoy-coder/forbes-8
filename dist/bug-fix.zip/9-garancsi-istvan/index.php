
        <?php
            $page = ['name' => 's', 'subpage' => '9-garancsi-istvan'];
            $metaTitle = '#9 - Garancsi István';
            include('../index.php');
        ?>
    
    