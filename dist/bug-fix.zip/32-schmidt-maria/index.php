
        <?php
            $page = ['name' => 's', 'subpage' => '32-schmidt-maria'];
            $metaTitle = '#32 - Schmidt Mária';
            include('../index.php');
        ?>
    
    