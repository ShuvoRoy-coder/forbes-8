
        <?php
            $page = ['name' => 's', 'subpage' => '11-rahimkulov-ruszlan'];
            $metaTitle = '#11 - Rahimkulov Ruszlán';
            include('../index.php');
        ?>
    
    