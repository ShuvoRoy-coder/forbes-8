
        <?php
            $page = ['name' => 's', 'subpage' => '8-szeles-gabor'];
            $metaTitle = '#8 - Széles Gábor';
            include('../index.php');
        ?>
    
    