
        <?php
            $page = ['name' => 's', 'subpage' => '35-harsanyi-zsolt'];
            $metaTitle = '#35 - Harsányi Zsolt';
            include('../index.php');
        ?>
    
    