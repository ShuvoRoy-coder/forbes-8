
        <?php
            $page = ['name' => 's', 'subpage' => '46-emori-gabor'];
            $metaTitle = '#46 - Emőri Gábor';
            include('../index.php');
        ?>
    
    