
        <?php
            $page = ['name' => 's', 'subpage' => '17-lakatos-peter'];
            $metaTitle = '#17 - Lakatos Péter';
            include('../index.php');
        ?>
    
    