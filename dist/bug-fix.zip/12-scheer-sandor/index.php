
        <?php
            $page = ['name' => 's', 'subpage' => '12-scheer-sandor'];
            $metaTitle = '#12 - Scheer Sándor';
            include('../index.php');
        ?>
    
    