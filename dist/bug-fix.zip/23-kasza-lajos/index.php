
        <?php
            $page = ['name' => 's', 'subpage' => '23-kasza-lajos'];
            $metaTitle = '#23 - Kasza Lajos';
            include('../index.php');
        ?>
    
    