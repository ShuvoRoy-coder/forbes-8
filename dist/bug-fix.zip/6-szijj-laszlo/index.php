
        <?php
            $page = ['name' => 's', 'subpage' => '6-szijj-laszlo'];
            $metaTitle = '#6 - Szíjj László';
            include('../index.php');
        ?>
    
    