
        <?php
            $page = ['name' => 's', 'subpage' => '25-leisztinger-tamas'];
            $metaTitle = '#25 - Leisztinger Tamás';
            include('../index.php');
        ?>
    
    