
        <?php
            $page = ['name' => 's', 'subpage' => '28-hernadi-zsolt'];
            $metaTitle = '#28 - Hernádi Zsolt';
            include('../index.php');
        ?>
    
    