
        <?php
            $page = ['name' => 's', 'subpage' => '24-varga-mihaly'];
            $metaTitle = '#24 - Varga Mihály';
            include('../index.php');
        ?>
    
    