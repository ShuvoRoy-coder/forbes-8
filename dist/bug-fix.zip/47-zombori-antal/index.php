
        <?php
            $page = ['name' => 's', 'subpage' => '47-zombori-antal'];
            $metaTitle = '#47 - Zombori Antal';
            include('../index.php');
        ?>
    
    