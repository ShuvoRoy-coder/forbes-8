
        <?php
            $page = ['name' => 's', 'subpage' => '45-szabo-miklos-es-csaladja'];
            $metaTitle = '#45 - Szabó Miklós és családja';
            include('../index.php');
        ?>
    
    