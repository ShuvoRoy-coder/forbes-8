
        <?php
            $page = ['name' => 's', 'subpage' => '26-keszthelyi-erik'];
            $metaTitle = '#26 - Keszthelyi Erik';
            include('../index.php');
        ?>
    
    