
        <?php
            $page = ['name' => 's', 'subpage' => '20-rahimkulov-timur'];
            $metaTitle = '#20 - Rahimkulov Timur';
            include('../index.php');
        ?>
    
    