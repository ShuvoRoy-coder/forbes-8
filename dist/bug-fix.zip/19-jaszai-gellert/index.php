
        <?php
            $page = ['name' => 's', 'subpage' => '19-jaszai-gellert'];
            $metaTitle = '#19 - Jászai Gellért';
            include('../index.php');
        ?>
    
    