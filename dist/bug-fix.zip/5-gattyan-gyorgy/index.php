
        <?php
            $page = ['name' => 's', 'subpage' => '5-gattyan-gyorgy'];
            $metaTitle = '#5 - Gattyán György';
            include('../index.php');
        ?>
    
    