
        <?php
            $page = ['name' => 's', 'subpage' => '38-bolgar-gyorgy'];
            $metaTitle = '#38 - Bolgár György';
            include('../index.php');
        ?>
    
    