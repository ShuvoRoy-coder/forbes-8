
        <?php
            $page = ['name' => 's', 'subpage' => '15-tiborcz-istvan'];
            $metaTitle = '#15 - Tiborcz István';
            include('../index.php');
        ?>
    
    