
        <?php
            $page = ['name' => 's', 'subpage' => '17-lekai-mate'];
            $metaTitle = '#17 - LÉKAI MÁTÉ';
            include('../index.php');
        ?>
    
    