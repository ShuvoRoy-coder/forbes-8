
        <?php
            $page = ['name' => 's', 'subpage' => '12-hanga-adam'];
            $metaTitle = '#12 - HANGA ÁDÁM';
            include('../index.php');
        ?>
    
    