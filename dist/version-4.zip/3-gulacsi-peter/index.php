
        <?php
            $page = ['name' => 's', 'subpage' => '3-gulacsi-peter'];
            $metaTitle = '#3 - GULÁCSI PÉTER';
            include('../index.php');
        ?>
    
    