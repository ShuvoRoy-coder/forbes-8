
        <?php
            $page = ['name' => 's', 'subpage' => '25-vogel-soma'];
            $metaTitle = '#25 - VOGEL SOMA';
            include('../index.php');
        ?>
    
    