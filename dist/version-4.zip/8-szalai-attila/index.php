
        <?php
            $page = ['name' => 's', 'subpage' => '8-szalai-attila'];
            $metaTitle = '#8 - SZALAI ATTILA';
            include('../index.php');
        ?>
    
    