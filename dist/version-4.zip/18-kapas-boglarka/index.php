
        <?php
            $page = ['name' => 's', 'subpage' => '18-kapas-boglarka'];
            $metaTitle = '#18 - KAPÁS BOGLÁRKA';
            include('../index.php');
        ?>
    
    