
        <?php
            $page = ['name' => 's', 'subpage' => '15-dibusz-denes'];
            $metaTitle = '#15 - DIBUSZ DÉNES';
            include('../index.php');
        ?>
    
    