
        <?php
            $page = ['name' => 's', 'subpage' => '20-kerkez-milos'];
            $metaTitle = '#20 - KERKEZ MILOS';
            include('../index.php');
        ?>
    
    