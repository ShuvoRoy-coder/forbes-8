
        <?php
            $page = ['name' => 's', 'subpage' => '23-varga-denes'];
            $metaTitle = '#23 - VARGA DÉNES';
            include('../index.php');
        ?>
    
    