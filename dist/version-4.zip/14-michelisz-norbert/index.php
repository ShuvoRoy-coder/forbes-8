
        <?php
            $page = ['name' => 's', 'subpage' => '14-michelisz-norbert'];
            $metaTitle = '#14 - MICHELISZ NORBERT';
            include('../index.php');
        ?>
    
    