
        <?php
            $page = ['name' => 's', 'subpage' => '21-gazdag-daniel'];
            $metaTitle = '#21 - GAZDAG DÁNIEL';
            include('../index.php');
        ?>
    
    