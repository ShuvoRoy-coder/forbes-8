
        <?php
            $page = ['name' => 's', 'subpage' => '19-varga-barnabas'];
            $metaTitle = '#19 - VARGA BARNABÁS';
            include('../index.php');
        ?>
    
    