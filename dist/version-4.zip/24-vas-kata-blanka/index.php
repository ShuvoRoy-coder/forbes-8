
        <?php
            $page = ['name' => 's', 'subpage' => '24-vas-kata-blanka'];
            $metaTitle = '#24 - VAS KATA BLANKA';
            include('../index.php');
        ?>
    
    