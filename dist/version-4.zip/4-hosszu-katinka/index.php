
        <?php
            $page = ['name' => 's', 'subpage' => '4-hosszu-katinka'];
            $metaTitle = '#4 - HOSSZÚ KATINKA';
            include('../index.php');
        ?>
    
    