
        <?php
            $page = ['name' => 's', 'subpage' => '2-szilagyi-aron'];
            $metaTitle = '#2 - SZILÁGYI ÁRON';
            include('../index.php');
        ?>
    
    