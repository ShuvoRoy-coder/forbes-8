
        <?php
            $page = ['name' => 's', 'subpage' => '22-marozsan-fabian'];
            $metaTitle = '#22 - MAROZSÁN FÁBIÁN';
            include('../index.php');
        ?>
    
    