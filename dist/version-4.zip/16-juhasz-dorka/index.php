
        <?php
            $page = ['name' => 's', 'subpage' => '16-juhasz-dorka'];
            $metaTitle = '#16 - JUHÁSZ DORKA';
            include('../index.php');
        ?>
    
    