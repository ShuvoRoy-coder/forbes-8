
        <?php
            $page = ['name' => 's', 'subpage' => '11-fucsovics-marton'];
            $metaTitle = '#11 - FUCSOVICS MÁRTON';
            include('../index.php');
        ?>
    
    