
        <?php
            $page = ['name' => 's', 'subpage' => '1-szoboszlai-dominik'];
            $metaTitle = '#1 - CSANYI SANDOR';
            include('../index.php');
        ?>
    
    