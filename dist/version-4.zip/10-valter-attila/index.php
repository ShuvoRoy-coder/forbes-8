
        <?php
            $page = ['name' => 's', 'subpage' => '10-valter-attila'];
            $metaTitle = '#10 - VALTER ATTILA';
            include('../index.php');
        ?>
    
    