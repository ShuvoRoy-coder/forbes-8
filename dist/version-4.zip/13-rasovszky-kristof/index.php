
        <?php
            $page = ['name' => 's', 'subpage' => '13-rasovszky-kristof'];
            $metaTitle = '#13 - RASOVSZKY KRISTÓF';
            include('../index.php');
        ?>
    
    