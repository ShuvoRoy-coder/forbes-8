
        <?php
            $page = ['name' => 's', 'subpage' => '5-schafer-andras'];
            $metaTitle = '#5 - SCHAFER ANDRÁS';
            include('../index.php');
        ?>
    
    