
        <?php
            $page = ['name' => 's', 'subpage' => '6-milak-kristof'];
            $metaTitle = '#6 - MILÁK KRISTÓF';
            include('../index.php');
        ?>
    
    