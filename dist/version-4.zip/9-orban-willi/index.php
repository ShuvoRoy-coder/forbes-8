
        <?php
            $page = ['name' => 's', 'subpage' => '9-orban-willi'];
            $metaTitle = '#9 - ORBÁN WILLI';
            include('../index.php');
        ?>
    
    