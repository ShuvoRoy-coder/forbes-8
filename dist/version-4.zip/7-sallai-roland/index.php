
        <?php
            $page = ['name' => 's', 'subpage' => '7-sallai-roland'];
            $metaTitle = '#7 - SALLAI ROLAND';
            include('../index.php');
        ?>
    
    